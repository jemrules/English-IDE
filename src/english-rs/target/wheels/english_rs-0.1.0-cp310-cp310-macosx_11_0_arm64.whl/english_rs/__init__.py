from .english_rs import *

__doc__ = english_rs.__doc__
if hasattr(english_rs, "__all__"):
    __all__ = english_rs.__all__